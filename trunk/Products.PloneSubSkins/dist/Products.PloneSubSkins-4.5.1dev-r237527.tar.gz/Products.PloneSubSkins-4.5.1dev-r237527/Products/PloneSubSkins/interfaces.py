# -*- coding: utf-8 -*-

from zope.interface import Interface


class ISubSkinsTool(Interface):
    """Marker interface for .SubSkinsTool.SubSkinsTool
    """
